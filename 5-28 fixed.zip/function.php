<?php
$conn = new mysqli("localhost", "root", "","d26893_busstops");
$conn->set_charset("utf8");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$router = $_GET['id'];
switch ($router) {
	case 'getnearby':
		$lat = $_POST['lat'];
		$lon = $_POST['lon'];
		$distance = $_POST['dis'];
		listNearBy($lat, $lon, $distance);
		break;

	case 'getstation':
		$area = $_POST['area'];
		listStation($area);
		break;
		
	case 'getarea':
		listArea();
		break;
	case 'getbuslist':
		$station = $_POST['station'];
		listBuses($station);
		break;

}

function listArea() {
	global $conn;
	$query = "SELECT stop_area FROM stops GROUP BY stop_area";
	$result = $conn->query($query);
	$data = array();
	if(!$result) {$data=["NO"]; }
	else {
		$data = $result->fetch_all();
		// $numrows =mysqli_num_rows($result);
		// for($count = 0; $count < $numrows; $count++){
		// 	$ac = mysqli_fetch_array($result, MYSQLI_ASSOC);
		// 	$data[] = $ac;
		// }
	}
	print_r(json_encode($data)) ;
	return ;
}

function listNearBy($lat, $long, $dis) {
	global $conn;
	$plusX = $dis*3280/(60*6075);
	$highLat = $plusX+$lat;
	$lowLat = $lat-$plusX;
	$plusY = $dis/(cos($lat*pi()/180)*111.321543);
	$highLong = $long+$plusY;
	$lowLong = $long-$plusY;
	$query = "SELECT stop_area  FROM stops WHERE stop_lat BETWEEN {$lowLat} AND {$highLat} AND stop_lon BETWEEN {$lowLong} AND {$highLong} GROUP BY stop_area";
	$result = $conn->query($query);
	$data = array();
	if(!$result) {$data=["NO"]; }
	else {
		$data = $result->fetch_all();
		// $numrows =mysqli_num_rows($result);
		// for($count = 0; $count < $numrows; $count++){
		// 	$ac = mysqli_fetch_array($result, MYSQLI_ASSOC);
		// 	$data[] = $ac;
		// }
	}
	print_r(json_encode($data)) ;
	return ;
}

function listStation($area) {
	global $conn;
	$query = "SELECT stop_name FROM stops WHERE stop_area='{$area}' GROUP BY stop_name";
	$result = $conn->query($query);
	$data = array();
	if(!$result) {$data=["NO"]; }
	else {
		$data = $result->fetch_all();
		// $numrows =mysqli_num_rows($result);
		// for($count = 0; $count < $numrows; $count++){
		// 	$ac = mysqli_fetch_array($result, MYSQLI_ASSOC);
		// 	$data[] = $ac;
		// }
	}
	print_r(json_encode($data)) ;
	return ;	
}

function listBuses($station) {
	global $conn;
	$query = "SELECT routes.route_id, routes.route_short_name FROM routes INNER JOIN (SELECT route_id FROM trips INNER JOIN (SELECT trip_id FROM stop_times  INNER JOIN stops ON stops.stop_id=stop_times.stop_id WHERE stops.stop_name='{$station}') AS tt1 ON trips.trip_id=tt1.trip_id) AS tt2 ON tt2.route_id=routes.route_id GROUP BY route_short_name ORDER BY route_short_name ASC";
	$result = $conn->query($query);
	$data = array();
	if(!$result) {$data=["NO"]; }
	else {
		$data = $result->fetch_all();
		// $numrows =mysqli_num_rows($result);
		// for($count = 0; $count < $numrows; $count++){
		// 	$ac = mysqli_fetch_array($result, MYSQLI_ASSOC);
		// 	$data[] = $ac;
		// }
	}
	print_r(json_encode($data)) ;
	return ;
}

?>